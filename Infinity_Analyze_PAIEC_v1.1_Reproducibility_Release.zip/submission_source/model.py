"""Infinity Analyze — Stanford PAIEC predictor v1.0.

Runtime-evidence hierarchical predictor for P(correct).
Uses only organizer-supplied visible fields and revealed labels:
  1) neutral/global prior,
  2) same-benchmark evidence from other subjects,
  3) exact-item evidence from other subjects,
  4) target subject's own same-benchmark labels,
  5) conservative lexical-neighborhood refinement.

No external benchmark tables, network calls, persistent state, or third-party packages.
"""
from __future__ import annotations

import math
import re
from typing import Iterable

_MIN_P = 0.03
_MAX_P = 0.97
_GLOBAL_PRIOR = 0.50
_BENCHMARK_PRIOR_STRENGTH = 12.0
_ITEM_PRIOR_STRENGTH = 5.0
_PAIR_PRIOR_STRENGTH = 6.0
_LOCAL_PRIOR_STRENGTH = 2.0
_ITEM_SHIFT_CAP = 0.035
_TOKEN_RE = re.compile(r"[A-Za-z0-9_]+")
_STOPWORDS = {
    "the","and","for","that","this","with","from","into","your","you","are","was","were",
    "has","have","had","not","but","can","could","would","should","will","about","what",
    "which","when","where","who","why","how","then","than","also","its","their","there",
    "here","using","use","used","given","below","above","following","answer","question",
    "please","one","two","each","all","any","some","more","most","only","same","other",
    "such","these","those","does","do","did","if","or","as","at","by","of","to","in","on"
}


def _safe_text(value) -> str:
    return str(value or "")


def _benchmark_id(item: dict) -> str:
    return _safe_text(item.get("benchmark_id", "")) if isinstance(item, dict) else ""


def _item_signature(item: dict) -> tuple[str, str, str, str]:
    if not isinstance(item, dict):
        return ("", "", "", "")
    return (
        _benchmark_id(item),
        _safe_text(item.get("item_content", "")),
        _safe_text(item.get("item_features", "")),
        _safe_text(item.get("interactors", "")),
    )


def _tokens(item: dict) -> set[str]:
    if not isinstance(item, dict):
        return set()
    text = " ".join(
        _safe_text(item.get(k, ""))
        for k in ("item_content", "item_features", "interactors")
    ).lower()
    return {t for t in _TOKEN_RE.findall(text) if len(t) > 2 and t not in _STOPWORDS}


def _similarity(a: dict, b: dict) -> float:
    ta, tb = _tokens(a), _tokens(b)
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def _valid_label(value) -> int | None:
    # JSON booleans are accepted as 0/1 insurance; official labels are 0/1.
    if isinstance(value, bool):
        return int(value)
    if value in (0, 1):
        return int(value)
    try:
        f = float(value)
    except (TypeError, ValueError):
        return None
    if f == 0.0:
        return 0
    if f == 1.0:
        return 1
    return None


def _iter_labels(labeled: Iterable):
    for entry in labeled or []:
        try:
            pair, y = entry
            obs_subject, obs_item = pair
        except Exception:
            continue
        if not isinstance(obs_subject, dict) or not isinstance(obs_item, dict):
            continue
        label = _valid_label(y)
        if label is None:
            continue
        yield obs_subject, obs_item, label


def _beta_mean(center: float, strength: float, successes: float, count: float) -> float:
    center = min(1.0, max(0.0, float(center)))
    strength = max(0.0, float(strength))
    count = max(0.0, float(count))
    return (center * strength + float(successes)) / (strength + count) if strength + count > 0 else center


def _item_complexity_shift(item: dict) -> float:
    """Tiny benchmark-agnostic adjustment from visible burden cues only.

    Kept deliberately smaller than prior versions because runtime pooled evidence
    is more trustworthy than hand-written complexity heuristics.
    """
    if not isinstance(item, dict):
        return 0.0
    content = _safe_text(item.get("item_content", ""))
    features = _safe_text(item.get("item_features", ""))
    interactors = _safe_text(item.get("interactors", ""))
    text = (content + " " + features + " " + interactors).lower()
    n = len(content)
    shift = 0.0

    if n >= 6000:
        shift -= 0.018
    elif n >= 2500:
        shift -= 0.012
    elif n >= 1000:
        shift -= 0.006
    elif 0 < n <= 220:
        shift += 0.005

    code_hits = sum(tok in text for tok in (
        "```", "traceback", "stack trace", " debug ", " patch ",
        " repository ", " implement ", " function ", " class ", " unit test",
    ))
    if code_hits >= 3:
        shift -= 0.012
    elif code_hits >= 1:
        shift -= 0.006

    proof_hits = sum(tok in text for tok in (
        " prove ", " proof ", " derive ", " show that ", " theorem ", " lemma ",
    ))
    if proof_hits >= 2:
        shift -= 0.010
    elif proof_hits == 1:
        shift -= 0.005

    tool_hits = sum(tok in text for tok in (
        " browser ", " website ", " click ", " navigate ", " tool ", " api ",
        " terminal ", " shell ", " agent ", " interactor ",
    ))
    if interactors.strip() or tool_hits >= 3:
        shift -= 0.010
    elif tool_hits >= 1:
        shift -= 0.004

    media_hits = sum(tok in text for tok in (
        " image ", " figure ", " screenshot ", " table ", " document ", " pdf ",
        " citation ", " chart ",
    ))
    if media_hits >= 3:
        shift -= 0.008
    elif media_hits >= 1:
        shift -= 0.003

    mcq_hits = sum(tok in text for tok in (
        "multiple choice", "choose the correct", "which of the following", "option a", "(a)",
    ))
    if mcq_hits >= 1 and n < 2500:
        shift += 0.007

    return max(-_ITEM_SHIFT_CAP, min(_ITEM_SHIFT_CAP, shift))


def _evidence(subject: dict, item: dict, labeled: Iterable):
    """Partition revealed evidence without double-counting target-pair labels.

    Hot path is deliberately inlined: hidden evaluation can pass a large shared
    label list to every prediction, so avoid generator/function-call overhead.
    """
    benchmark = _benchmark_id(item)
    if not benchmark:
        return (0, 0, 0, 0, [])

    target_content = _safe_text(item.get("item_content", ""))
    target_features = _safe_text(item.get("item_features", ""))
    target_interactors = _safe_text(item.get("interactors", ""))

    other_bench_success = 0
    other_bench_n = 0
    other_item_success = 0
    other_item_n = 0
    own = []

    # Local bindings reduce attribute/global lookup overhead in large scans.
    valid_label = _valid_label
    safe_text = _safe_text
    for entry in labeled or ():
        try:
            pair, raw_y = entry
            obs_subject, obs_item = pair
            if not isinstance(obs_item, dict) or not isinstance(obs_subject, dict):
                continue
            if safe_text(obs_item.get("benchmark_id", "")) != benchmark:
                continue
            y = valid_label(raw_y)
            if y is None:
                continue
        except Exception:
            continue

        if obs_subject == subject:
            own.append((obs_item, y))
            continue

        other_bench_success += y
        other_bench_n += 1

        # Compare exact-item fields lazily only after benchmark + subject checks.
        if (safe_text(obs_item.get("item_content", "")) == target_content and
                safe_text(obs_item.get("item_features", "")) == target_features and
                safe_text(obs_item.get("interactors", "")) == target_interactors):
            other_item_success += y
            other_item_n += 1

    return (
        other_bench_success, other_bench_n,
        other_item_success, other_item_n,
        own,
    )


def _clip(p: float) -> float:
    try:
        p = float(p)
    except (TypeError, ValueError):
        return 0.5
    if not math.isfinite(p):
        return 0.5
    return float(min(_MAX_P, max(_MIN_P, p)))


def predict(input: list[dict], labeled: list | None = None) -> float:
    """Predict P(correct) using hierarchical runtime evidence.

    Budget 0 starts near 0.5 with only a tiny item-complexity adjustment. At
    positive budgets, labels from other subjects on the same anonymous benchmark
    estimate benchmark difficulty; exact-item outcomes from other subjects refine
    item difficulty; target-subject labels then estimate subject fit within that
    benchmark. No public benchmark outcome tables are embedded in the model.
    """
    try:
        if not isinstance(input, (list, tuple)) or len(input) != 2:
            return 0.5
        subject, item = input
        if not isinstance(subject, dict) or not isinstance(item, dict):
            return 0.5

        base = _GLOBAL_PRIOR + _item_complexity_shift(item)
        base = min(0.60, max(0.40, base))

        bs, bn, its, itn, own = _evidence(subject, item, labeled or [])

        # Other subjects on this benchmark reveal benchmark-level difficulty.
        benchmark_p = _beta_mean(base, _BENCHMARK_PRIOR_STRENGTH, bs, bn)

        # Exact same item across other subjects reveals item difficulty. The
        # item posterior is shrunk to the already-learned benchmark base.
        item_p = _beta_mean(benchmark_p, _ITEM_PRIOR_STRENGTH, its, itn)

        if not own:
            return _clip(item_p)

        # Target subject's own labels update around the pooled benchmark/item prior.
        successes = sum(y for _, y in own)
        n = len(own)
        pair_p = _beta_mean(item_p, _PAIR_PRIOR_STRENGTH, successes, n)

        # Lexical neighborhoods are only trusted after strong overlap. This is a
        # small refinement, not the main adaptation mechanism.
        weighted_success = 0.0
        weighted_total = 0.0
        max_sim = 0.0
        for obs_item, y in own:
            sim = _similarity(item, obs_item)
            max_sim = max(max_sim, sim)
            if sim < 0.35:
                continue
            weight = sim
            weighted_success += weight * y
            weighted_total += weight

        if weighted_total <= 0.0 or max_sim < 0.45:
            return _clip(pair_p)

        local_p = _beta_mean(item_p, _LOCAL_PRIOR_STRENGTH, weighted_success, weighted_total)
        local_mix = min(0.35, 0.35 * (max_sim - 0.45) / 0.55)
        return _clip((1.0 - local_mix) * pair_p + local_mix * local_p)
    except Exception:
        # Harness insurance: malformed unexpected inputs should not create scorer 40.
        return 0.5
