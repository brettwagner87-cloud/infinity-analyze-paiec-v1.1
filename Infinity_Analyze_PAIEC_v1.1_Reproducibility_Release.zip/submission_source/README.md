# Infinity Analyze — Stanford PAIEC v1.1 Random Acquisition A/B

Single-variable formative A/B against v1.0.

- `model.py` is byte-for-byte identical to v1.0 runtime-fix.
- `labeling.py` is intentionally omitted so the organizer's default random acquisition policy is used.
- Purpose: test whether removing uncertainty/novelty acquisition improves calibration of the hierarchical Beta estimator by making acquired labels more representative of the subject–benchmark pair.
- No external data, network calls, persistent state, or third-party packages.

This build should be compared against v1.0 using recurring anonymous subject/benchmark IDs where available, because formative samples are redrawn between submissions.
