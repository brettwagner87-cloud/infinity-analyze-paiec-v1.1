# Infinity Analyze — PAIEC v1.1 Reproducibility Release

This package accompanies the frozen Infinity Analyze submission for the
Stanford Predictive AI Evaluation Competition (PAIEC).

## Frozen candidate

Submission artifact:

`Infinity_Analyze_Stanford_PAIEC_v1.1_random_acquisition.zip`

SHA-256:

`734d670df4dc7cb7df80f46fd4c0c8bf94fe4c2f7e1e393bb932676c70409470`

The competition submission itself contains exactly:

- `model.py`
- `README.md`

The frozen Codabench artifact must not be modified in place.

## Method summary

The predictor estimates correctness probability using a lightweight hierarchy:

1. global prior plus a small item-burden adjustment;
2. same-benchmark evidence pooled across other subjects;
3. exact-item evidence pooled across other subjects;
4. target-subject evidence on the benchmark;
5. conservative lexical-neighborhood refinement.

The model intentionally omits `labeling.py`, allowing the organizer's default
acquisition policy to run.

## Dependencies

The submitted predictor uses only the Python standard library.

For the included smoke test, a standard Python 3 interpreter is sufficient.

## Reproduce the smoke checks

From this directory:

```bash
python smoke_test.py
```

Expected result:

```text
PASS
```

The smoke checks verify:

- importability;
- deterministic output;
- finite probability range;
- safe malformed-input behavior;
- cross-benchmark isolation;
- same-benchmark evidence handling.

They do not attempt to reproduce Stanford's hidden formative or final scores,
because those datasets are not distributed to participants.

## Development evidence

Observed formative Brier ALC values during development:

| Version | Brier ALC | Main change |
|---|---:|---|
| v1.0 | 0.200679 | custom uncertainty/novelty acquisition |
| v1.1 | 0.173371 | default random acquisition; current frozen candidate |
| v1.2 | 0.179591 | logit-offset experiment |
| v1.3 | 0.212130 | exact-item strength 5→3 |
| v1.4 | 0.210117 | global prior 0.50→0.40 |

Formative samples are redrawn between submissions, so these values are not
treated as paired measurements of causal improvement.

## Data-use statement

The frozen submission contains no external benchmark outcome tables and no
private-test identifiers. Public Measurement Data Bank access was investigated
for local validation, but the frozen v1.1 behavior does not depend on external
files at runtime.

## LLM-assistance disclosure

LLM-based coding assistance was used for code review, debugging, experiment
design, documentation, and report drafting. The final frozen code and artifacts
were inspected and validated before selection.

## Release contents

- `submission_source/model.py` — exact source from frozen v1.1 ZIP
- `submission_source/README.md` — exact README from frozen v1.1 ZIP
- `smoke_test.py` — local contract checks
- `CHECKSUMS.txt` — artifact/source hashes
- `METHOD_CARD.md` — concise implementation description
- `DISCLOSURES.md` — data and LLM-assistance disclosures
- `RELEASE_MANIFEST.json` — machine-readable release inventory
