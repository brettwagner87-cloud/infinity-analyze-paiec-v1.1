#!/usr/bin/env python3
"""
Minimal smoke tests for Infinity Analyze PAIEC v1.1.

These tests do not use any private or hidden competition data.
They only verify interface behavior, determinism, finite probability output,
benchmark isolation, and fail-closed handling.
"""
from pathlib import Path
import importlib.util, math

HERE = Path(__file__).resolve().parent
MODEL = HERE / "submission_source" / "model.py"

spec = importlib.util.spec_from_file_location("infinity_paiec_v11", MODEL)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

subject = {
    "normalized_name": "synthetic_subject",
    "provider": "",
    "release_date": "",
    "access_date": "",
    "harness": "",
    "harness_version": "",
    "reasoning_effort": "",
    "subject_features_extra": "",
}

item = {
    "benchmark_id": "benchmark_A",
    "item_content": "Solve a short synthetic arithmetic question.",
    "item_features": "",
    "interactors": "",
}

# 1. Basic contract
p = float(m.predict([subject, item], []))
assert math.isfinite(p), p
assert 0.0 <= p <= 1.0, p

# 2. Determinism
p2 = float(m.predict([subject, item], []))
assert p == p2, (p, p2)

# 3. Malformed input fails safely
q = float(m.predict(None, []))
assert math.isfinite(q) and 0.0 <= q <= 1.0, q

# 4. Cross-benchmark isolation
other_item = dict(item)
other_item["benchmark_id"] = "benchmark_B"
labels = [([subject, other_item], False) for _ in range(20)]
r = float(m.predict([subject, item], labels))
assert math.isfinite(r) and 0.0 <= r <= 1.0, r

# 5. Same-benchmark evidence should be usable
same_item = dict(item)
labels2 = [([subject, same_item], True) for _ in range(3)]
s = float(m.predict([subject, item], labels2))
assert math.isfinite(s) and 0.0 <= s <= 1.0, s

print("PASS")
print("budget0 =", p)
print("cross_benchmark_isolated =", r)
print("same_benchmark_example =", s)
