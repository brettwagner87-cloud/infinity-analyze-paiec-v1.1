# Disclosures

## Training / development data
The frozen v1.1 submission does not require or read external data at runtime.
No private test data were used or accessed.

Public Stanford/AIMS Measurement Data Bank access was obtained during
development for prospective local validation work. The frozen v1.1 candidate
was selected before any such public-data optimization was incorporated into
its runtime behavior.

## LLM coding assistance
LLM-based coding assistance was used during development for:
- implementation review;
- debugging;
- experiment design;
- adversarial review preparation;
- documentation and report drafting.

The participant remained responsible for the final submitted artifact and its
selection.

## Hidden-set caution
Codabench formative samples are redrawn between submissions. Cross-run score
differences are therefore treated as noisy and are not presented as exact
paired causal estimates.
