# Method Card

## Name
Infinity Analyze PAIEC v1.1

## Objective
Estimate the probability that an AI subject answers an item correctly under
sparse, budgeted revealed-label conditions.

## Core estimator
- Global prior centered at 0.50.
- Small item-burden shift capped at ±0.035.
- Same-benchmark Beta-style pooling with pseudo-count strength 12.
- Exact-item evidence with shrinkage strength 5.
- Target-subject evidence with shrinkage strength 6.
- Conservative lexical refinement using stopword-filtered token overlap.

## Design constraints
- Standard library only.
- No network access.
- No file access.
- No subprocess access.
- No persistent state.
- No benchmark-name outcome lookup tables.
- No private test identifiers.
- Empty benchmark IDs fail closed.

## Acquisition
No custom `labeling.py` is provided. Organizer-default acquisition is used.

## Selection rationale
v1.1 is the best observed formative candidate and survived two independent
external audits. Later one-variable experiments did not provide sufficiently
reproducible evidence to replace it.
